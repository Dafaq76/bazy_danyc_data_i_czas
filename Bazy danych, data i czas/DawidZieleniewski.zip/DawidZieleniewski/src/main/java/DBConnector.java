import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnector {

    private static Connection getConnection() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost/figury",
                    "root",
                    ""
            );
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return conn;
    }

    public static ResultSet executeQuery(String sql) {
        ResultSet rs = null;
        try {
            rs = getConnection().createStatement().executeQuery(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return rs;
    }

    public static void execute(String sql) {
        try {
            getConnection().createStatement().execute(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws SQLException {
        int ans = 0;
        Instant start, end;

        while (ans != 3) {
            ans = menu();

            if (ans == 1) {
                start = Instant.now();
                dodajNowyTrojkat();
                end = Instant.now();
                System.out.println("Czas wykonania operacji to: " + Duration.between(start, end).toMillis() + " millisekund");
            }
            else if (ans == 2) {
                start = Instant.now();
                wyswietlTrojkaty();
                end = Instant.now();
                System.out.println("Czas wykonania operacji to: " + Duration.between(start, end).toMillis() + " millisekund");
            }
        }
    }

    public static int menu() {
        System.out.println("");
        System.out.println("-----------------------------------------");
        System.out.println("Wybierz opcję");
        System.out.println("1. Dodaj nowy trojkat do bazy");
        System.out.println("2. Odczytaj trojkaty z bazy");
        System.out.println("3. Wyjscie");

        return new Scanner(System.in).nextInt();
    }

    public static void dodajNowyTrojkat() {
        float a, b, c, o, p;
        double pole;

        System.out.println("Podaj dlugosc boku A: ");
        a = new Scanner(System.in).nextInt();

        System.out.println("Podaj dlugosc boku B: ");
        b = new Scanner(System.in).nextInt();

        System.out.println("Podaj dlugosc boku C: ");
        c = new Scanner(System.in).nextInt();

        o = a+b+c;
        p = o/2;
        pole = Math.sqrt(p*(p-a)*(p-b)*(p-c));

        DBConnector.execute("INSERT INTO trojkaty(dlugoscA, dlugoscB, dlugoscC, obwod, pole) VALUES (%f, %f, %f, %f, %f)"
                .formatted(a, b, c, o, pole));
    }

    public static void wyswietlTrojkaty() throws SQLException {

        ResultSet rs = DBConnector.executeQuery("SELECT * FROM trojkaty");

        while (rs.next()) {
            System.out.println("====================================");
            System.out.println("ID: " + rs.getString(1));
            System.out.println("Dlugosc boku A: " + rs.getString(2));
            System.out.println("Dlugosc boku B: " + rs.getString(3));
            System.out.println("Dlugosc boku C: " + rs.getString(4));
            System.out.println("Obwod: " + rs.getString(5));
            System.out.println("Pole: " + rs.getString(6));
            System.out.println("Czas dodania: " + rs.getString(7));
        }
    }
}
